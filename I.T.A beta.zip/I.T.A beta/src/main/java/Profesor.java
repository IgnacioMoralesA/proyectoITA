public class Profesor {
    public static void menuProfesor(){




    }
}
