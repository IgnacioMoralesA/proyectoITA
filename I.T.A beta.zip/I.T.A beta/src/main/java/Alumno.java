public class Alumno {
    public static void menuAlumno(){




    }
}
