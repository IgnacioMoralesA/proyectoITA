
import java.util.*;
public class Registrar {
    public static void MenuRegistro(){
        Scanner sn = new Scanner(System.in);
        String teclado;
        System.out.println("A continuacion escriba sus datos de registro:");
        System.out.print("Usuario: ");
        teclado = sn.next();
        System.out.print("Contraseña: ");
        teclado = sn.next();

    }
}
