package Guis;

import Herramientas.CalculadoraBasica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class VentanaCalculadoraBasica extends Ventana{
    private JButton[] botonesNumeros = new JButton[10];
    private ArrayList<JButton> botonesFunciones = new ArrayList<>();
    private JButton botonSumar,botonRestar,botonMulti,botonDividir, botonModulo;
    private JButton botonDecimal, botonResultado, botonAC, botonSigno;
    private JTextField textoCalculadora;

    private char operador;
    private double num1, num2, resultado;


    public VentanaCalculadoraBasica() {
        super("Calculadora Básica", 330, 500);
        iniciarComponentes();
    }

    private void iniciarComponentes() {
        botonesNumeros();
        botonesFunciones();
        campoTexto();
    }

    private void botonesFunciones() {
        this.botonesFunciones.add(this.botonSumar = generarBoton("+",230,310,60,60));
        this.botonesFunciones.add(this.botonRestar = generarBoton("-",230,240,60,60));
        this.botonesFunciones.add(this.botonMulti = generarBoton("*",230,170,60,60));
        this.botonesFunciones.add(this.botonDividir = generarBoton("/",230,100,60,60));
        this.botonesFunciones.add(this.botonModulo = generarBoton("%",160,100,60,60));
        this.botonesFunciones.add(this.botonResultado = generarBoton("=",230,380,60,60));
        this.botonesFunciones.add(this.botonAC = generarBoton("AC",20,100,60,60));
        this.botonesFunciones.add(this.botonSigno = generarBoton("+/-",90,100,60,60));
        this.botonesFunciones.add(this.botonDecimal = generarBoton(",",160,380,60,60));

        for (JButton button : this.botonesFunciones) {
            this.add(button);
            button.addActionListener(this);
        }
    }

    private void botonesNumeros() {
        this.botonesNumeros[0] = generarBoton("0",20,380,130,60);
        this.botonesNumeros[1] = generarBoton("1",20,310,60,60);
        this.botonesNumeros[2] = generarBoton("2",90,310,60,60);
        this.botonesNumeros[3] = generarBoton("3",160,310,60,60);
        this.botonesNumeros[4] = generarBoton("4",20,240,60,60);
        this.botonesNumeros[5] = generarBoton("5",90,240,60,60);
        this.botonesNumeros[6] = generarBoton("6",160,240,60,60);
        this.botonesNumeros[7] = generarBoton("7",20,170,60,60);
        this.botonesNumeros[8] = generarBoton("8",90,170,60,60);
        this.botonesNumeros[9] = generarBoton("9",160,170,60,60);

        for (int i = 0; i < botonesNumeros.length; i++) {
            this.add(this.botonesNumeros[i]);
            this.botonesNumeros[i].addActionListener(this);
        }

    }

    private void campoTexto() {
        this.textoCalculadora = generarJTextField(20,30,270,60);
        this.textoCalculadora.setEnabled(false);
        this.textoCalculadora.setFont(new Font("Calibri", 3, 30));
        this.add(this.textoCalculadora);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        for (int i = 0; i < this.botonesNumeros.length; i++) {
            if(e.getSource() == this.botonesNumeros[i]) {
                this.textoCalculadora.setText(this.textoCalculadora.getText().concat(String.valueOf(i)));
            }
        }
        if(e.getSource()==botonDecimal) {
            this.textoCalculadora.setText(this.textoCalculadora.getText().concat("."));
        }
        if(e.getSource()==botonSumar) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='+';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonRestar) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='-';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonMulti) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='*';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonDividir) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='/';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonModulo) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='%';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonResultado) {
            num2=Double.parseDouble(this.textoCalculadora.getText());

            switch(operador) {
                case'+':
                    resultado = CalculadoraBasica.sumar(num1,num2);
                    break;
                case'-':
                    resultado = CalculadoraBasica.restar(num1,num2);
                    break;
                case'*':
                    resultado = CalculadoraBasica.multiplicar(num1,num2);
                    break;
                case'/':
                    resultado = CalculadoraBasica.dividir(num1,num2);
                    break;
                case'%':
                    resultado = CalculadoraBasica.modulo(num1,num2);
                    break;
            }
            this.textoCalculadora.setText(String.valueOf(resultado));
            num1 = resultado;
        }
        if(e.getSource()==botonAC) {
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonSigno) {
            double temp = Double.parseDouble(this.textoCalculadora.getText());
            temp *= -1;
            this.textoCalculadora.setText(String.valueOf(temp));
        }
    }
}
