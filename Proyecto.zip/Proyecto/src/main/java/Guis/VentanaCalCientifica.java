package Guis;

import javax.swing.*;
import java.awt.event.ActionListener;

//public class VentanaCalCientifica implements ActionListener {
    //JFrame frame;
    //JTextField textField;
    //JButton[] numberButtons = new JButton[10];
//}
