package Guis;

import Herramientas.CalculadoraBasica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class VentanaCalculadoraCientifica extends Ventana{
    private JButton[] botonesNumeros = new JButton[10];
    private ArrayList<JButton> botonesFunciones = new ArrayList<>();
    private JButton botonSumar,botonRestar,botonMulti,botonDividir, botonModulo;
    private JButton botonDecimal, botonResultado, botonAC, botonDelete, botonSigno;
    private JButton botonRaiz, botonPotencia, botonPorcentaje, botonFactorial, botonLog, botonLog10, botonAbs;
    private JButton botonSumatoria, botonSeno, botonCoseno, botonTan, botonAseno, botonAcos, botonAtan;
    private JComboBox listaOpciones;
    private JTextField textoCalculadora;

    private double num1, num2, resultado;
    private char operador;

    public VentanaCalculadoraCientifica() {
        super("Calculadora Científica", 330, 640);
        iniciarComponentes();
    }

    private void iniciarComponentes() {
        botonesFunciones();
        botonesNumeros();
        campoTexto();
        listaDesplegable();
    }

    private void listaDesplegable() {
        String[] opciones = {"Ecuaciones Cuadráticas","Perímetros, Áreas o Volúmenes",
                "Sistema de Ecuaciones","Ecuaciones de la recta","Matrices"};
        this.listaOpciones = generarListaDesplegable(opciones,20,550,270,40);
        this.add(this.listaOpciones);
        this.listaOpciones.addActionListener(this);
    }

    private void botonesFunciones() {
        this.botonesFunciones.add(this.botonSumatoria = generarBoton("SUM",20,100,60,40));
        this.botonesFunciones.add(this.botonPorcentaje = generarBoton("%",90,100,60,40));
        this.botonesFunciones.add(this.botonAC = generarBoton("AC",160,100,60,40));
        this.botonesFunciones.add(this.botonDelete = generarBoton("DEL",230,100,60,40));
        this.botonesFunciones.add(this.botonRaiz = generarBoton("RZ",20,150,60,40));
        this.botonesFunciones.add(this.botonFactorial = generarBoton("FAC",90,150,60,40));
        this.botonesFunciones.add(this.botonLog = generarBoton("LN",160,150,60,40));
        this.botonesFunciones.add(this.botonLog10 = generarBoton("LOG",230,150,60,40));
        this.botonesFunciones.add(this.botonAseno = generarBoton("ASIN",90,200,60,40));
        this.botonesFunciones.add(this.botonAcos = generarBoton("ACOS",160,200,60,40));
        this.botonesFunciones.add(this.botonAtan = generarBoton("ATAN",230,200,60,40));
        this.botonesFunciones.add(this.botonPotencia = generarBoton("POT",20,200,60,40));
        this.botonesFunciones.add(this.botonAbs = generarBoton("ABS",20,250,60,40));
        this.botonesFunciones.add(this.botonSeno = generarBoton("SIN",90,250,60,40));
        this.botonesFunciones.add(this.botonCoseno = generarBoton("COS",160,250,60,40));
        this.botonesFunciones.add(this.botonTan = generarBoton("TAN",230,250,60,40));
        this.botonesFunciones.add(this.botonModulo = generarBoton("MOD",90,300,60,40));
        this.botonesFunciones.add(this.botonSigno = generarBoton("+/-",160,300,60,40));
        this.botonesFunciones.add(this.botonDividir = generarBoton("/",230,300,60,40));
        this.botonesFunciones.add(this.botonMulti = generarBoton("*",230,350,60,40));
        this.botonesFunciones.add(this.botonRestar = generarBoton("-",230,400,60,40));
        this.botonesFunciones.add(this.botonSumar = generarBoton("+",230,450,60,40));
        this.botonesFunciones.add(this.botonDecimal = generarBoton(",",160,500,60,40));
        this.botonesFunciones.add(this.botonResultado = generarBoton("=",230,500,60,40));

        for (JButton button : this.botonesFunciones) {
            button.setFont(new Font("Calibri", 1, 11));
            this.add(button);
            button.addActionListener(this);
        }
    }

    private void botonesNumeros() {
        this.botonesNumeros[0] = generarBoton("0",20,500,130,40);
        this.botonesNumeros[1] = generarBoton("1",20,450,60,40);
        this.botonesNumeros[2] = generarBoton("2",90,450,60,40);
        this.botonesNumeros[3] = generarBoton("3",160,450,60,40);
        this.botonesNumeros[4] = generarBoton("4",20,400,60,40);
        this.botonesNumeros[5] = generarBoton("5",90,400,60,40);
        this.botonesNumeros[6] = generarBoton("6",160,400,60,40);
        this.botonesNumeros[7] = generarBoton("7",20,350,60,40);
        this.botonesNumeros[8] = generarBoton("8",90,350,60,40);
        this.botonesNumeros[9] = generarBoton("9",160,350,60,40);

        for (JButton botonesNumero : botonesNumeros) {
            this.add(botonesNumero);
            botonesNumero.addActionListener(this);
        }
    }

    private void campoTexto() {
        this.textoCalculadora = generarJTextField(20,30,270,60);
        this.textoCalculadora.setEnabled(false);
        this.textoCalculadora.setFont(new Font("Calibri", 3, 30));
        this.add(this.textoCalculadora);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        for (int i = 0; i < this.botonesNumeros.length; i++) {
            if(e.getSource() == this.botonesNumeros[i]) {
                this.textoCalculadora.setText(this.textoCalculadora.getText().concat(String.valueOf(i)));
            }
        }
        if(e.getSource()==botonDecimal) {
            this.textoCalculadora.setText(this.textoCalculadora.getText().concat("."));
        }
        if(e.getSource()==botonSumar) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='+';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonRestar) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='-';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonMulti) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='*';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonDividir) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='/';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonModulo) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='M';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonRaiz) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='R';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonPotencia) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='P';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonPorcentaje) {
            num1 = Double.parseDouble(this.textoCalculadora.getText());
            operador ='%';
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonResultado) {
            num2=Double.parseDouble(this.textoCalculadora.getText());

            switch(operador) {
                case'+':
                    resultado = CalculadoraBasica.sumar(num1,num2);
                    break;
                case'-':
                    resultado = CalculadoraBasica.restar(num1,num2);
                    break;
                case'*':
                    resultado = CalculadoraBasica.multiplicar(num1,num2);
                    break;
                case'/':
                    resultado = CalculadoraBasica.dividir(num1,num2);
                    break;
                case'%':
                    resultado = CalculadoraBasica.modulo(num1,num2);
                    break;
            }
            this.textoCalculadora.setText(String.valueOf(resultado));
            num1 = resultado;
        }
        if(e.getSource()==botonAC) {
            this.textoCalculadora.setText("");
        }
        if(e.getSource()==botonSigno) {
            double temp = Double.parseDouble(this.textoCalculadora.getText());
            temp *= -1;
            this.textoCalculadora.setText(String.valueOf(temp));
        }
    }
}
