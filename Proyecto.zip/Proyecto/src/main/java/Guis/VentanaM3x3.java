package Guis;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaM3x3 extends Ventana{
    JPanel panel;
    JTextField textField1;
    JTextField textField2;
    JTextField textField3;
    JTextField textField4;
    JTextField textField5;
    JTextField textField6;
    JTextField textField7;
    JTextField textField8;
    JTextField textField9;
    JTextField textField10;
    JLabel label;

    public VentanaM3x3(String nombre, int largoX, int largoY) {
        super(nombre, largoX, largoY);
        iniciarcomponentes();
    }

    private void iniciarcomponentes() {
        panelVentana();
        camposDeTextoVentanas();
        etiquetasVentana();
        botonesVentana();
    }

    private void etiquetasVentana() {
        generarJLabel(label," = ",200,70,50,50);
    }

    private void panelVentana() {
        panel=new JPanel();
        this.add(panel);
    }

    private void camposDeTextoVentanas() {
        textField1=generarJTextField(20,20,50,50);
        this.add(textField1);
        textField2=generarJTextField(70,20,50,50);
        this.add(textField2);
        textField3=generarJTextField(120,20,50,50);
        this.add(textField3);
        textField4=generarJTextField(20,70,50,50);
        this.add(textField4);
        textField5=generarJTextField(70,70,50,50);
        this.add(textField5);
        textField6=generarJTextField(120,70,50,50);
        this.add(textField6);
        textField7=generarJTextField(20,120,50,50);
        this.add(textField7);
        textField8=generarJTextField(70,120,50,50);
        this.add(textField8);
        textField9=generarJTextField(120,120,50,50);
        this.add(textField9);
        textField10=generarJTextField(240,70,150,50);
        this.add(textField10);
    }

    private void botonesVentana() {
        JButton button1 = generarBoton("7",20,180,50,50);
        this.add(button1);
        JButton button2 = generarBoton("8",70,180,50,50);
        this.add(button2);
        JButton button3 = generarBoton("9",120,180,50,50);
        this.add(button3);
        JButton button4 = generarBoton("4",20,230,50,50);
        this.add(button4);
        JButton button5 = generarBoton("5",70,230,50,50);
        this.add(button5);
        JButton button6 = generarBoton("6",120,230,50,50);
        this.add(button6);
        JButton button7 = generarBoton("1",20,280,50,50);
        this.add(button7);
        JButton button8 = generarBoton("2",70,280,50,50);
        this.add(button8);
        JButton button9 = generarBoton("3",120,280,50,50);
        this.add(button9);
        JButton button10 = generarBoton("AC",20,330,50,50);
        this.add(button10);
        JButton button11 = generarBoton("0",70,330,50,50);
        this.add(button11);
        JButton button12 = generarBoton("<-",120,330,50,50);
        this.add(button12);
        JButton button13 = generarBoton("Determinante",20,380,150,50);
        this.add(button13);
        accionBotones(button1,button2,button3,button4,button5,button6,button7,button8,button9,button10,button11,button12,button13);
    }

    private void accionBotones(JButton button1, JButton button2, JButton button3, JButton button4, JButton button5, JButton button6, JButton button7, JButton button8, JButton button9, JButton button10, JButton button11, JButton button12, JButton button13) {
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button11.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button12.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        button13.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }
}