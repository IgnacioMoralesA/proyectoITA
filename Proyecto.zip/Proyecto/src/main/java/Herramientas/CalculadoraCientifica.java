package Herramientas;/*
*agregar
-integrales
-derivadas
*/
import java.util.LinkedList;
import java.util.Scanner;

public class CalculadoraCientifica extends CalculadoraBasica{

    static Scanner leer = new Scanner(System.in);

    public static double[] ingresarNumeros(String[] operadores) {
        double[] numeros = new double[operadores.length];
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Ingrese "+operadores[i]);
            numeros[i] = leer.nextDouble();
        }
        return numeros;
    }

    public static double raiz(double a){
        /*String[] operadores={"numero: "};
        double[] numero=ingresarNumeros(operadores);
        if(numero[0]<0){
            String[] imaginario ={Math.sqrt(numero[0]*(-1))+"i"};
            String b= (imaginario[0]);
            System.out.println(b);
        }
        if(numero[0]>=0){
            double a=Math.sqrt(numero[0]);
            resultado(a);
        }*/
        if(a<0){
            System.out.println("Math error");
            return 0;
        }else {
            return Math.sqrt(a);
        }
    }

    public static double potencia(double a, double b) {
        /*String[] operadores = {"la base","el exponente: "};
        double[] numeros = ingresarNumeros(operadores);
        double a = numeros[0];
        double b = numeros[1];
        double potenciaNumero = Math.pow(a,b);
        resultado(potenciaNumero);*/
        return Math.pow(a,b);
    }

    public static double porcentaje(double a, double b) {
        /*String[] operadores = {"el 1er número","el 2do número: "};
        double[] numeros = ingresarNumeros(operadores);
        double a = numeros[0];
        double b = numeros[1];
        b /= 100;
        double porcentajeNumero = a*b;
        resultado(porcentajeNumero);*/
        b /= 100;
        return a*b;
    }

    public static double seno(double a){
        /*String[] operadores={"numero: "};
        double[] numeros= CalculadoraCientifica.ingresarNumeros(operadores);
        double grado=Math.sin(numeros[0]);
        CalculadoraCientifica.resultado(grado);*/
        return Math.sin(a);
    }

    public static double coseno(double a){
        /*String[] operadores={"numero: "};
        double[] numeros=CalculadoraCientifica.ingresarNumeros(operadores);
        double grado=Math.cos(numeros[0]);
        CalculadoraCientifica.resultado(grado);*/
        return Math.cos(a);
    }

    public static double tangente(double a){
        /*String[] operadores={"numero: "};
        double[] numeros=CalculadoraCientifica.ingresarNumeros(operadores);
        double a=Math.tan(numeros[0]);
        CalculadoraCientifica.resultado(a);*/
        return Math.tan(a);
    }

    public static double aSeno(double a){
        /*String[] operadores={"numero: "};
        double[] numeros=CalculadoraCientifica.ingresarNumeros(operadores);
        double a=Math.asin(numeros[0]);
        CalculadoraCientifica.resultado(a);*/
        return Math.asin(a);
    }

    public static double aCoseno(double a){
        /*String[] operadores={"numero: "};
        double[] numeros=CalculadoraCientifica.ingresarNumeros(operadores);
        double a=Math.acos(numeros[0]);
        CalculadoraCientifica.resultado(a);*/
        return Math.acos(a);
    }

    public static double aTangente(double a){
        /*String[] operadores={"numero: "};
        double[] numero=CalculadoraCientifica.ingresarNumeros(operadores);
        double a=Math.atan(numero[0]);
        CalculadoraCientifica.resultado(a);*/
        return Math.atan(a);
    }

    public static double factoriales(double a) {
        /*System.out.println("ingrese dato: ");
        double a = leer.nextDouble();
        int fact = 1;
        for( int i = 0; i <= a; i++ ) {
            fact *= (i+1);
        }
        resultado(fact);*/
        int fact = 1;
        for( int i = 0; i <= a; i++ ) {
            fact *= (i+1);
        }
        return fact;
    }

    public static double logaritmoNatural(double a){
        /*String[] operadores={"numero: "};
        double[] numeros=ingresarNumeros(operadores);
        double a=Math.log(numeros[0]);
        resultado(a);*/
        return Math.log(a);
    }

    public static double logaritmo10(double a){
        /*String[] operadores={"numero: "};
        double[] numeros=ingresarNumeros(operadores);
        double a=Math.log10(numeros[0]);
        resultado(a);*/
        return Math.log10(a);
    }

    public static double valorAbsoluto(double a){
        /*String[] operadores={"numero: "};
        double[] numero=ingresarNumeros(operadores);
        double a;
        if(numero[0]<0){
            a = numero[0] * -1;
        }else{
            a = numero[0];
        }
        resultado(a);*/
        return Math.abs(a);
    }

    public static void divisores(double a) {
        /*String[] operadores ={"numero"};
        double[] numeros=ingresarNumeros(operadores);
        Double a=numeros[0];*/
        LinkedList<Double>Divisores = agregarDivisores(a);

    }

    public static LinkedList agregarDivisores(Double numero) {
        LinkedList<Double>Divisores = new LinkedList<>();
        for (int i=1;i<(numero+1);i++){
            if(numero%i==0) {
                Divisores.add((double) i);
            }
        }
        mostrarDivisores(Divisores);
        return Divisores;
    }

    private static void mostrarDivisores(LinkedList<Double> divisores) {
        System.out.println(divisores);
    }

    public static double sumatoria(double a){
        /*String[] operadores={"numero hasta donde quiera sumar: " };
        double[] numero=ingresarNumeros(operadores);
        double iNumero = numero[0];
        double iSumatorio = 0;
        double iContador = iNumero;
        while (iContador != 0) {
            iSumatorio = iSumatorio + iContador;
            iContador--;
        }
        resultado(iSumatorio);*/
        double iSumatorio = 0;
        double iContador = a;
        while (iContador != 0) {
            iSumatorio = iSumatorio + iContador;
            iContador--;
        }
        return iSumatorio;
    }

    public static double cbrt(double a){
        /*String[] operadores={"numero: "};
        double[] numeros=ingresarNumeros(operadores);
        double a=Math.cbrt(numeros[0]);
        resultado(a);*/
        return Math.cbrt(a);
    }

    public static void resultado(double resultado){
        System.out.println("El resultado es = "+resultado);
    }
}