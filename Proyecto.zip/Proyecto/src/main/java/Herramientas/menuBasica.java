package Herramientas;

import java.util.Scanner;

public class menuBasica {

    static Scanner leer=new Scanner(System.in);
/*
    public static void Herramientas.menuBasica(){
        try{
            menuCalculadora();
        }catch (Exception e){
            System.out.println("Valor no valido.");
        }
    }

    public static void menuCalculadora(){
        int eleccion;
        do {
            do {
                mostraropciones();
                eleccion=leer.nextInt();
                switch (eleccion){
                    case 1:
                        Herramientas.CalculadoraBasica.sumar();
                        break;
                    case 2:
                        Herramientas.CalculadoraBasica.restar();
                        break;
                    case 3:
                        Herramientas.CalculadoraBasica.multiplicar();
                        break;
                    case 4:
                        Herramientas.CalculadoraBasica.dividir();
                        break;
                    case 5:
                        Herramientas.CalculadoraBasica.mayor();
                        break;
                    case 6:
                        Herramientas.CalculadoraBasica.menor();
                        break;
                    case 7:
                        break;
                }
            }while (eleccion<1 || eleccion >7);
        }while (eleccion!=7);
    }

    public static void mostraropciones(){
        System.out.println("=====MENU=====");
        System.out.println("[1] Sumar");
        System.out.println("[2] Restar");
        System.out.println("[3] Multiplicar");
        System.out.println("[4] Dividir");
        System.out.println("[5] Mayor");
        System.out.println("[6] Menor");
        System.out.println("[7] Salir");
    }*/
}