package Herramientas;

public class CalculadoraBasica {

    public static double sumar(double a, double b) {
        /*String[] operadores = {"el 1er número: ","el 2do número: "};
        double[] numeros = Herramientas.CalculadoraCientifica.ingresarNumeros(operadores);
        double a = numeros[0];
        double b = numeros[1];
        double suma = a+b;
        Herramientas.CalculadoraCientifica.resultado(suma);*/
        return a+b;
    }

    public static double restar(double a, double b) {
        /*String[] operadores = {"el 1er número: ","el 2do número: "};
        double[] numeros = Herramientas.CalculadoraCientifica.ingresarNumeros(operadores);
        double a = numeros[0];
        double b = numeros[1];
        double resta = a-b;
        Herramientas.CalculadoraCientifica.resultado(resta);*/
        return a-b;
    }

    public static double multiplicar(double a, double b) {
        /*String[] operadores = {"el 1er factor: ","el 2do factor: "};
        double[] numeros = Herramientas.CalculadoraCientifica.ingresarNumeros(operadores);
        double a = numeros[0];
        double b = numeros[1];
        double multiplicacion = a*b;
        Herramientas.CalculadoraCientifica.resultado(multiplicacion);*/
        return a*b;
    }

    public static double dividir(double a, double b){
        /*String[] operadores = {"el dividendo: ","el divisor: "};
        double[] numeros = Herramientas.CalculadoraCientifica.ingresarNumeros(operadores);
        if(numeros[1]==0){
            System.out.println("No existe solucion");
        }else{
            double a = numeros[0];
            double b = numeros[1];
            double division = a/b;
            Herramientas.CalculadoraCientifica.resultado(division);
        }*/
        return a/b;
    }

    public static double mayor(double a, double b) {
        /*String[] operadores = {"el 1er número: ","el 2do número: "};
        double[] numeros = Herramientas.CalculadoraCientifica.ingresarNumeros(operadores);
        double a = numeros[0];
        double b = numeros[1];
        double numeroMayor = Math.max(a,b);
        Herramientas.CalculadoraCientifica.resultado(numeroMayor);*/
        return Math.max(a,b);
    }

    public static double menor(double a, double b) {
        /*String[] operadores = {"el 1er número: ","el 2do número: "};
        double[] numeros = Herramientas.CalculadoraCientifica.ingresarNumeros(operadores);
        double a = numeros[0];
        double b = numeros[1];
        double numeroMenor = Math.min(a,b);
        Herramientas.CalculadoraCientifica.resultado(numeroMenor);*/
        return Math.min(a,b);
    }

    public static double modulo(double a, double b){
        /*String[] operadores={"numero: ","numero: "};
        double[] numero=Herramientas.CalculadoraCientifica.ingresarNumeros(operadores);
        double a=numero[0];
        double b=numero[1];
        double mod=a%b;
        Herramientas.CalculadoraCientifica.resultado(mod);*/
        return a%b;
    }
}