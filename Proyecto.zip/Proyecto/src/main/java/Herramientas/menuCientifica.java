package Herramientas;

import java.util.Scanner;

public class menuCientifica {
    static Scanner leer = new Scanner(System.in);
/*
    public static void mCientifica(){
        try{
            menuCalculadora();
        }catch (Exception e){
            System.out.println("Valor no valido.");
        }
    }

    public static void menuCalculadora(){
        int eleccion;
        do {
            do {
                mostrarOpcionesMenu();
                eleccion = leer.nextInt();
                switch (eleccion) {
                    case 1:
                        Herramientas.CalculadoraBasica.sumar();
                        break;
                    case 2:
                        Herramientas.CalculadoraBasica.restar();
                        break;
                    case 3:
                        Herramientas.CalculadoraBasica.multiplicar();
                        break;
                    case 4:
                        Herramientas.CalculadoraBasica.dividir();
                        break;
                    case 5:
                        Herramientas.CalculadoraCientifica.raiz();
                        break;
                    case 6:
                        Herramientas.CalculadoraBasica.mayor();
                        break;
                    case 7:
                        Herramientas.CalculadoraBasica.menor();
                        break;
                    case 8:
                        Herramientas.CalculadoraCientifica.potencia();
                        break;
                    case 9:
                        Herramientas.CalculadoraCientifica.porcentaje();
                        break;
                    case 10:
                        Herramientas.ecuaciones.ecuacionCuadratica();
                        break;
                    case 11:
                        Herramientas.FigurasGeometricas.figurasGeometricas();
                        break;
                    case 12:
                        Herramientas.ecuaciones.sistemaEcuaciones();
                        break;
                    case 13:
                        Herramientas.ecuaciones.ecuacionRecta();
                        break;
                    case 14:
                        Herramientas.CalculadoraCientifica.factoriales();
                        break;
                    case 15:
                        Herramientas.CalculadoraCientifica.divisores();
                        break;
                    case 16:
                        Herramientas.CalculadoraCientifica.logaritmoNatural();
                        break;
                    case 17:
                        Herramientas.CalculadoraCientifica.logaritmo10();
                        break;
                    case 18:
                        Herramientas.trigonometricas.seno();
                        break;
                    case 19:
                        Herramientas.trigonometricas.coseno();
                        break;
                    case 20:
                        Herramientas.trigonometricas.tangente();
                        break;
                    case 21:
                        Herramientas.trigonometricas.aSeno();
                        break;
                    case 22:
                        Herramientas.trigonometricas.aCoseno();
                        break;
                    case 23:
                        Herramientas.trigonometricas.aTangente();
                        break;
                    case 24:
                        Herramientas.Matrices.menuMatriz();
                        break;
                    case 25:
                        Herramientas.CalculadoraCientifica.valorAbsoluto();
                        break;
                    case 26:
                        Herramientas.CalculadoraCientifica.sumatoria();
                        break;
                    case 27:
                        Herramientas.CalculadoraCientifica.cbrt();
                        break;
                    case 28:
                        break;
                }
            } while (eleccion < 1 || eleccion > 28);
        }while (eleccion != 28);
    }

    public static void mostrarOpcionesMenu(){
        System.out.println("=====MENU=====");
        System.out.println("Qué operación desea realizar? ");
        System.out.println("[1] Sumar");
        System.out.println("[2] Restar");
        System.out.println("[3] Multiplicar");
        System.out.println("[4] Dividir");
        System.out.println("[5] Raiz");
        System.out.println("[6] Sacar el número mayor");
        System.out.println("[7] Sacar el número menor");
        System.out.println("[8] Potencia");
        System.out.println("[9] Porcentaje");
        System.out.println("[10] Ecuación Cuadrática");
        System.out.println("[11] Perímetros, Áreas o Volúmenes");
        System.out.println("[12] Sistema de Ecuaciones (2 incógnitas)");
        System.out.println("[13] Ecuaciones de la recta");
        System.out.println("[14] Factoriales");
        System.out.println("[15] Divisores");
        System.out.println("[16] Logaritmo natural");
        System.out.println("[17] Logaritmo base 10");
        System.out.println("[18] Seno");
        System.out.println("[19] Coseno");
        System.out.println("[20] Tangeno");
        System.out.println("[21] Arco Seno");
        System.out.println("[22] Arco Coseno");
        System.out.println("[23] Arco Tangente");
        System.out.println("[24] Matriz");
        System.out.println("[25] Valor absoluto");
        System.out.println("[26] Sumatoria");
        System.out.println("[27] Raiz cubica");
        System.out.println("[28] Salir");
    }*/
}