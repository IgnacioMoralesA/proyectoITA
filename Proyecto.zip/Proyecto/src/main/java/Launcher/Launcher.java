package Launcher;

import Guis.VentanaCalculadoraBasica;
import Guis.VentanaCalculadoraCientifica;
import Guis.VentanaM3x3;

public class Launcher {
    public static void main(String[] args) {
        //VentanaM3x3 ventanaM3x3=new VentanaM3x3("MATRICES",500,500);
        //VentanaCalculadoraBasica ventanaCalculadoraBasica = new VentanaCalculadoraBasica();
        VentanaCalculadoraCientifica ventanaCalculadoraCientifica = new VentanaCalculadoraCientifica();
    }
}
